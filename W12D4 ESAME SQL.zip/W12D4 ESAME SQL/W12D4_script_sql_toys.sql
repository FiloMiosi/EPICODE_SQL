/*Verificare che i campi definiti come PK siano univoci*/

SELECT ProductID, COUNT(*) 
FROM Product 
GROUP BY ProductID 
HAVING COUNT(*) > 1;

SELECT RegionID, COUNT(*) 
FROM Region 
GROUP BY RegionID 
HAVING COUNT(*) > 1;

SELECT SalesID, COUNT(*) 
FROM Sales 
GROUP BY SalesID 
HAVING COUNT(*) > 1;

/*Le query non restituiscono alcun risultato, significa che tutte le chiavi primarie sono univoche e non ci sono duplicati*/

/* Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno */

SELECT 
    p.ProductName AS Prodotto,
    YEAR(s.SaleDate) AS Anno,
    SUM(s.Quantity * p.Price) AS FatturatoTotale
FROM 
    Product p
JOIN 
    Sales s ON p.ProductID = s.ProductID
GROUP BY 
    p.ProductName, YEAR(s.SaleDate)
ORDER BY 
    p.ProductName, YEAR(s.SaleDate);

    
    /* Esporre fatturato totale annuo per stato */ 
    SELECT 
    RegionName AS Zona,
    YEAR(sales.SaleDate) AS Anno,
    SUM(sales.Quantity * product.Price) AS FatturatoTotale
FROM 
    Sales 
JOIN 
    Region  ON sales.RegionID = region.RegionID
JOIN 
    Product  ON sales.ProductID = product.ProductID
GROUP BY 
    region.RegionName, YEAR(sales.SaleDate)
ORDER BY 
    YEAR(sales.SaleDate) ASC, SUM(sales.Quantity * product.Price) DESC;

/* Trovare la merce più richiesta sul mercato */

SELECT 
    p.Category AS Categoria,
    SUM(s.Quantity) AS QuantitaTotale
FROM 
    Product p
JOIN 
    Sales s ON p.ProductID = s.ProductID
GROUP BY 
    p.Category
ORDER BY 
    SUM(s.Quantity) DESC
LIMIT 1;
/* Quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti. */

SELECT 
    p.ProductID,
    p.ProductName
FROM 
    Product p
LEFT JOIN 
    Sales s ON p.ProductID = s.ProductID
WHERE 
    s.SalesID IS NULL; /*Primo approccio*/
    
    SELECT 
    ProductID,
    ProductName
FROM 
    Product p
WHERE 
    NOT EXISTS (
        SELECT 1
        FROM Sales s
        WHERE p.ProductID = s.ProductID
    ); /*Secondo approccio*/
    
    /*Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente) */
    
    SELECT 
    p.ProductID,
    p.ProductName,
    MAX(s.SaleDate) AS UltimaDataVendita
FROM 
    Product p
LEFT JOIN 
    Sales s ON p.ProductID = s.ProductID
GROUP BY 
    p.ProductID, p.ProductName;
    
    