*Creazione database ToysGroup
[Product]
  - ProductID (PK)
  - ProductName
  - Categoria
  - Prezzo

[Region]
  - IDRegione (PK)
  - NomeRegione

[Sales]
  - SalesID (PK)
  - SaleDate
  - Quantity
  - ProductID (FK)
  - RegionID (FK) 

CREATE SCHEMA `toysgroup`

CREATE TABLE Product (
    ProductID INT PRIMARY KEY,
    ProductName VARCHAR(255),
    Category VARCHAR(255),
    Price DECIMAL(10, 2)
);

CREATE TABLE Region (
    RegionID INT PRIMARY KEY,
    RegionName VARCHAR(255)
);

CREATE TABLE Sales (
    SalesID INT PRIMARY KEY,
    SaleDate DATE,
    Quantity INT,
    ProductID INT,
    RegionID INT,
    FOREIGN KEY (ProductID) REFERENCES Product(ProductID),
    FOREIGN KEY (RegionID) REFERENCES Region(RegionID)
);

INSERT INTO Product (ProductID, ProductName, Category, Price) VALUES
(1, 'Orso', 'Peluches', 19.99),
(2, 'Set Lego', 'Costruzioni', 49.99),
(3, 'Automobilina', 'Veicoli', 9.99),
(4, 'Bambola', 'Bambole', 14.99),
(5, 'Personaggio d\'azione', 'Personaggi d\'azione', 24.99),
(6, 'Puzzle', 'Puzzle', 12.99),
(7, 'Gioco da tavolo', 'Giochi da tavolo', 29.99),
(8, 'Set ferroviario', 'Veicoli', 39.99),
(9, 'Drone', 'Elettronica', 99.99),
(10, 'Robot', 'Elettronica', 89.99),
(11, 'Bicicletta', 'Giochi all\'aperto', 149.99),
(12, 'Monopattino', 'Giochi all\'aperto', 59.99),
(13, 'Aquilone', 'Giochi all\'aperto', 9.99),
(14, 'Play-Doh', 'Arte e artigianato', 5.99),
(15, 'Pastelli', 'Arte e artigianato', 2.99),
(16, 'Modellino di aereo', 'Modelli', 39.99),
(17, 'Auto RC', 'Radiocomandati', 69.99),
(18, 'Set d\'azione', 'Personaggi d\'azione', 30.00),
(19, 'Yo-Yo', 'Giochi classici', 4.99),
(20, 'Kit di magia', 'Magia', 19.99);

INSERT INTO Region (RegionID, RegionName) VALUES
(1, 'Nord America'),
(2, 'Europa'),
(3, 'Asia'),
(4, 'Sud America'),
(5, 'Africa'),
(6, 'Australia'),
(7, 'Medio Oriente'),
(8, 'America Centrale'),
(9, 'Caraibi'),
(10, 'Europa Orientale'),
(11, 'Europa Occidentale'),
(12, 'Sud-est asiatico'),
(13, 'Africa del Nord'),
(14, 'Africa subsahariana'),
(15, 'Africa meridionale'),
(16, 'Asia orientale'),
(17, 'Asia meridionale'),
(18, 'Asia centrale'),
(19, 'Isole del Pacifico'),
(20, 'Scandinavia');

INSERT INTO Sales (SalesID, SaleDate, Quantity, ProductID, RegionID) VALUES
(1, '2024-01-01', 5, 1, 1),
(2, '2024-01-02', 3, 2, 2),
(3, '2024-01-03', 7, 3, 3),
(4, '2024-01-04', 2, 4, 4),
(5, '2024-01-05', 6, 5, 5),
(6, '2024-01-06', 4, 6, 6),
(7, '2024-01-07', 8, 7, 7),
(8, '2024-01-08', 1, 8, 8),
(9, '2024-01-09', 9, 9, 9),
(10, '2024-01-10', 2, 10, 10),
(11, '2024-01-11', 3, 11, 11),
(12, '2024-01-12', 5, 12, 12),
(13, '2024-01-13', 6, 13, 13),
(14, '2024-01-14', 4, 14, 14),
(15, '2024-01-15', 7, 15, 15),
(16, '2024-01-16', 8, 16, 16),
(17, '2024-01-17', 1, 17, 17),
(18, '2024-01-18', 9, 18, 18),
(19, '2024-01-19', 2, 19, 19),
(20, '2024-01-20', 3, 20, 20);



