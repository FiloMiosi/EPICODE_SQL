SELECT factresellersales.OrderQuantity, dimproduct.EnglishProductName
FROM factresellersales
JOIN dimproduct ON factresellersales.ProductKey = dimproduct.ProductKey;
/* Prodotti venduti*/