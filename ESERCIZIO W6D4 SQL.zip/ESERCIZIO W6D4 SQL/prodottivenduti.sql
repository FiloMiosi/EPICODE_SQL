SELECT DISTINCT A.EnglishProductName
FROM DimProduct A
JOIN FactResellerSales B ON A.ProductKey = B.ProductKey
WHERE SalesAmount > 0; 
