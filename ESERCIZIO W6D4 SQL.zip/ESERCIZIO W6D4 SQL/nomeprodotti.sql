SELECT A.*, EnglishProductSubcategoryName
FROM dimproduct A
JOIN dimproductsubcategory B ON A.ProductSubcategoryKey = B.ProductSubcategoryKey
/* Esposto il nome dei prodotti con categoria e sottocategoria*/