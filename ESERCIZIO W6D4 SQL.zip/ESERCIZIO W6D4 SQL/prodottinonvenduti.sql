SELECT dimproduct.englishproductname
FROM dimproduct
WHERE dimproduct.FinishedGoodsFlag = 1
AND dimproduct.ProductKey NOT IN (SELECT DISTINCT ProductKey FROM factresellersales);
/*Prodotti non venduti*/