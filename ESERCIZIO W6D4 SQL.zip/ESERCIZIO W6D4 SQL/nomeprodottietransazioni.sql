SELECT FactResellerSales.*, DimProduct.EnglishProductName
FROM FactResellerSales
JOIN DimProduct ON FactResellerSales.ProductKey = DimProduct.ProductKey;
/*Esposto il nome dei prodotti con transazioni di vendita/*