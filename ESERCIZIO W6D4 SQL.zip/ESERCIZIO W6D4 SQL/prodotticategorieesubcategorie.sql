SELECT A.*, EnglishProductSubcategoryName, C.EnglishProductCategoryName
FROM dimproduct A
JOIN dimproductsubcategory B ON A.ProductSubcategoryKey = B.ProductSubcategoryKey
JOIN dimproductcategory C ON B.ProductCategoryKey = C.ProductCategoryKey
/* Esposto il nome dei prodotti con categoria e sottocategoria*/