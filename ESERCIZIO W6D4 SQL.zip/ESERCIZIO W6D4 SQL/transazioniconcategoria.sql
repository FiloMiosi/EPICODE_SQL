SELECT FactResellerSales.*, DimProductSubcategory.EnglishProductSubcategoryName
FROM FactResellerSales
JOIN DimProduct ON FactResellerSales.ProductKey = DimProduct.ProductKey
JOIN DimProductSubcategory ON DimProduct.ProductSubcategoryKey = DimProductSubcategory.ProductSubcategoryKey;
/*Esposto elenco transazioni con categoria/*