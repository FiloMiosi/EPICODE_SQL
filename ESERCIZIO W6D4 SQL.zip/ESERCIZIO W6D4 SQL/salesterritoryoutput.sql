SELECT 
    FactResellerSales.SalesOrderNumber,
    FactResellerSales.SalesOrderLineNumber,
    FactResellerSales.OrderDate,
    FactResellerSales.UnitPrice,
    FactResellerSales.OrderQuantity,
    FactResellerSales.TotalProductCost,
    DimProduct.EnglishProductName AS ProductName,
    DimProductSubcategory.EnglishProductSubcategoryName AS ProductCategory,
    DimReseller.ResellerName,
    dimsalesterritory.SalesTerritoryCountry
FROM 
    FactResellerSales
JOIN 
    DimProduct ON FactResellerSales.ProductKey = DimProduct.ProductKey
JOIN 
    DimProductSubcategory ON DimProduct.ProductSubcategoryKey = DimProductSubcategory.ProductSubcategoryKey
JOIN 
    DimReseller ON FactResellerSales.ResellerKey = DimReseller.ResellerKey
JOIN 
    dimsalesterritory ON FactResellerSales.SalesTerritoryKey = Dimsalesterritory.SalesTerritoryKey;
    /*Output con Prodotti e regione di vendita/*